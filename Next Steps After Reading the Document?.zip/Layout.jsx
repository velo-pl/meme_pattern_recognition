import React from 'react';
import Header from './Header';
import Footer from './Footer';
import Sidebar from './Sidebar'; // Import the Sidebar

const Layout = ({ children }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Header />
      <div style={{ display: 'flex', flexGrow: 1 }}>
        <Sidebar /> {/* Add the Sidebar component here */}
        <main style={{ flexGrow: 1, padding: '1rem' }}>
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Layout;
