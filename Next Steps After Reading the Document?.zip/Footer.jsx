import React from 'react';

const Footer = () => {
  return (
    <footer style={{ backgroundColor: '#f0f0f0', padding: '1rem', textAlign: 'center', position: 'fixed', bottom: 0, width: '100%' }}>
      <p>&copy; 2025 Meme Coin Pattern Recognition Platform. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
