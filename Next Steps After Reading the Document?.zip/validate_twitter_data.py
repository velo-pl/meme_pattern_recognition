#!/usr/bin/env python3.11
import psycopg2
import json

DB_NAME = "meme_coin_db"
DB_USER = "manus_user"
DB_PASSWORD = "manus_password"
DB_HOST = "localhost"
DB_PORT = "5432"

def validate_twitter_data_insertion(limit: int = 1):
    """
    Connects to the PostgreSQL database, queries the twitter_data table,
    and prints a sample of the inserted data to validate.

    Args:
        limit: Number of records to fetch and print (default 1).
    """
    conn = None
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )
        cur = conn.cursor()

        print(f"Fetching {limit} sample record(s) from twitter_data table...")
        cur.execute(f"SELECT id, query, search_type, collected_at, tweet_data FROM twitter_data ORDER BY id DESC LIMIT {limit}")
        records = cur.fetchall()

        if not records:
            print("No records found in twitter_data table.")
            return

        for record in records:
            print("\n--- Sample Record ---")
            print(f"ID: {record[0]}")
            print(f"Query: {record[1]}")
            print(f"Search Type: {record[2]}")
            print(f"Collected At: {record[3]}")
            # Pretty print the JSONB data
            tweet_data_json = record[4]
            if isinstance(tweet_data_json, str): # If it's a string, parse it
                tweet_data_json = json.loads(tweet_data_json)
            print(f"Tweet Data (first 200 chars): {json.dumps(tweet_data_json, indent=2)[:200]}...")
        print("\nValidation successful if data looks correct.")

    except psycopg2.Error as e:
        print(f"Database error during validation: {e}")
    except Exception as e:
        print(f"An unexpected error occurred during validation: {e}")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    validate_twitter_data_insertion()

