import React from 'react';

const Header = () => {
  return (
    <header style={{ backgroundColor: '#f0f0f0', padding: '1rem', textAlign: 'center' }}>
      <h1>Meme Coin Pattern Recognition Platform</h1>
    </header>
  );
};

export default Header;
