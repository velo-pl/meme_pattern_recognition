import React from 'react';

const Sidebar = () => {
  return (
    <aside style={{ width: '200px', backgroundColor: '#e0e0e0', padding: '1rem' }}>
      <nav>
        <ul>
          <li><a href="/">Dashboard</a></li>
          <li><a href="/coins">Coin List</a></li>
          {/* Add more navigation links as needed */}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
