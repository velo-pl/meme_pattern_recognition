#!/usr/bin/env python3.11
import json
import pandas as pd
import argparse
import os
from collections import Counter

# For sentiment analysis, NLTK's VADER is a good starting point if available.
# We'll include a placeholder for it. If NLTK is not pre-installed, it would need to be.
# For now, we'll focus on more direct text and engagement features.
# try:
#     from nltk.sentiment.vader import SentimentIntensityAnalyzer
#     nltk_available = True
# except ImportError:
#     nltk_available = False
#     print("NLTK VADER not found. Sentiment features will be basic or skipped.")

def engineer_twitter_features(json_file_path: str, output_csv_file: str, query_term: str):
    """
    Reads Twitter data from a JSON file, engineers basic features,
    and saves them to a CSV file.

    Args:
        json_file_path: Path to the input JSON file containing Twitter data.
        output_csv_file: Path to the output CSV file for engineered features.
        query_term: The original query term used to collect this data (for context).
    """
    if not os.path.exists(json_file_path):
        print(f"Error: JSON file not found at {json_file_path}")
        pd.DataFrame([{"error": f"JSON file not found at {json_file_path}"}]).to_csv(output_csv_file, index=False)
        return

    try:
        with open(json_file_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from {json_file_path}: {e}")
        pd.DataFrame([{"error": f"Error decoding JSON: {e}"}]).to_csv(output_csv_file, index=False)
        return
    except Exception as e:
        print(f"Error reading file {json_file_path}: {e}")
        pd.DataFrame([{"error": f"Error reading file: {e}"}]).to_csv(output_csv_file, index=False)
        return

    engineered_features_list = []

    try:
        if "result" not in raw_data or "timeline" not in raw_data["result"] or "instructions" not in raw_data["result"]["timeline"]:
            print(f"Error: Unexpected JSON structure in {json_file_path}. Missing expected keys (result/timeline/instructions).")
            pd.DataFrame([{"error": "Unexpected JSON structure"}]).to_csv(output_csv_file, index=False)
            return

        tweets_processed = 0
        for instruction in raw_data["result"]["timeline"].get("instructions", []):
            if instruction.get("type") == "TimelineAddEntries":
                for entry in instruction.get("entries", []):
                    # Tweets are often nested deeper
                    if entry.get("content", {}).get("entryType") == "TimelineTimelineItem" and \
                       entry.get("content", {}).get("itemContent", {}).get("itemType") == "TimelineTweet":
                        
                        tweet_content = entry["content"]["itemContent"].get("tweet_results", {}).get("result", {})
                        legacy_tweet_data = tweet_content.get("legacy", {})
                        user_legacy_data = tweet_content.get("core", {}).get("user_results", {}).get("result", {}).get("legacy", {})

                        if not legacy_tweet_data: # Skip if no core tweet data
                            continue
                        
                        tweets_processed += 1
                        features = {
                            "query_term": query_term,
                            "tweet_id": tweet_content.get("rest_id", None),
                            "created_at": legacy_tweet_data.get("created_at", None),
                            "full_text": legacy_tweet_data.get("full_text", ""),
                            "retweet_count": legacy_tweet_data.get("retweet_count", 0),
                            "favorite_count": legacy_tweet_data.get("favorite_count", 0),
                            "reply_count": legacy_tweet_data.get("reply_count", 0),
                            "quote_count": legacy_tweet_data.get("quote_count", 0),
                            "lang": legacy_tweet_data.get("lang", None),
                            "user_id": user_legacy_data.get("id_str", tweet_content.get("core", {}).get("user_results", {}).get("result", {}).get("rest_id")),
                            "user_screen_name": user_legacy_data.get("screen_name", None),
                            "user_followers_count": user_legacy_data.get("followers_count", 0),
                            "user_friends_count": user_legacy_data.get("friends_count", 0),
                            "user_verified": user_legacy_data.get("verified", False),
                            "user_statuses_count": user_legacy_data.get("statuses_count", 0),
                            "user_created_at": user_legacy_data.get("created_at", None)
                        }

                        # Basic text features
                        features["text_length"] = len(features["full_text"])
                        features["word_count"] = len(features["full_text"].split())
                        features["has_mention"] = "@" in features["full_text"]
                        features["has_hashtag"] = "#" in features["full_text"]
                        features["has_url"] = "http" in features["full_text"].lower()
                        
                        # Placeholder for VADER sentiment (if NLTK was available and setup)
                        # if nltk_available and features["full_text"]:
                        #     analyzer = SentimentIntensityAnalyzer()
                        #     vs = analyzer.polarity_scores(features["full_text"])
                        #     features["sentiment_compound"] = vs["compound"]
                        #     features["sentiment_pos"] = vs["pos"]
                        #     features["sentiment_neg"] = vs["neg"]
                        #     features["sentiment_neu"] = vs["neu"]
                        # else:
                        features["sentiment_compound"] = None # Placeholder

                        engineered_features_list.append(features)
                    
                    # Also check for user entries if the search type was "People"
                    elif entry.get("content", {}).get("entryType") == "TimelineTimelineModule" and \
                         entry.get("content", {}).get("items", []):
                        for item_entry in entry.get("content", {}).get("items", []):
                            if item_entry.get("item", {}).get("itemContent", {}).get("itemType") == "TimelineUser":
                                user_results = item_entry["item"]["itemContent"].get("user_results", {}).get("result", {})
                                if user_results:
                                    tweets_processed +=1 # Count as an item processed
                                    user_legacy = user_results.get("legacy", {})
                                    features = {
                                        "query_term": query_term,
                                        "user_id": user_results.get("rest_id"),
                                        "user_screen_name": user_legacy.get("screen_name"),
                                        "user_name": user_legacy.get("name"),
                                        "user_description": user_legacy.get("description"),
                                        "user_followers_count": user_legacy.get("followers_count", 0),
                                        "user_friends_count": user_legacy.get("friends_count", 0),
                                        "user_verified": user_legacy.get("verified", False),
                                        "user_statuses_count": user_legacy.get("statuses_count", 0),
                                        "user_created_at": user_legacy.get("created_at", None),
                                        "is_user_profile": True # Flag to distinguish from tweet features
                                    }
                                    engineered_features_list.append(features)

        if not engineered_features_list:
            if tweets_processed == 0:
                print(f"No tweet or user entries found in the expected structure within {json_file_path}.")
                pd.DataFrame([{"error": "No tweet/user entries found in JSON"}]).to_csv(output_csv_file, index=False)
            else:
                 print(f"Data processed but no features generated for {json_file_path}. Check logic.")
                 pd.DataFrame([{"error": "No features generated from processed data"}]).to_csv(output_csv_file, index=False)
            return

        df = pd.DataFrame(engineered_features_list)
        df.to_csv(output_csv_file, index=False)
        print(f"Successfully engineered Twitter features for query 	'{query_term}\' and saved to {output_csv_file}. Processed {tweets_processed} items.")

    except KeyError as e:
        print(f"KeyError while processing Twitter JSON structure in {json_file_path}: {e}. Check API response format.")
        pd.DataFrame([{"error": f"KeyError: {e}"}]).to_csv(output_csv_file, index=False)
    except Exception as e:
        print(f"An unexpected error occurred during Twitter feature engineering for {json_file_path}: {e}")
        pd.DataFrame([{"error": str(e)}]).to_csv(output_csv_file, index=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Engineer features from Twitter JSON data.")
    parser.add_argument("-f", "--file", type=str, required=True, help="Path to the input JSON file (e.g., twitter_search_results.json).")
    parser.add_argument("-o", "--output_csv", type=str, required=True, help="Path to the output CSV file for engineered features.")
    parser.add_argument("-q", "--query_term", type=str, required=True, help="Original query term used for context.")

    args = parser.parse_args()
    engineer_twitter_features(args.file, args.output_csv, args.query_term)

