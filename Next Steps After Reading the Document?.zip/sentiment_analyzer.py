#!/usr/bin/env python3.11
import pandas as pd
import argparse
import os

# Attempt to import NLTK and VADER
try:
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    import nltk
    # Check if vader_lexicon is downloaded, if not, attempt to download
    try:
        nltk.data.find("sentiment/vader_lexicon.zip")
    except nltk.downloader.DownloadError:
        print("VADER lexicon not found. Attempting to download...")
        nltk.download("vader_lexicon", quiet=True)
        print("VADER lexicon downloaded.")
    analyzer = SentimentIntensityAnalyzer()
    nltk_vader_available = True
except ImportError:
    print("NLTK or VADER lexicon not found. Please ensure NLTK is installed and vader_lexicon is downloaded.")
    print("Sentiment analysis will be skipped.")
    nltk_vader_available = False

def apply_sentiment_analysis(input_csv_path: str, output_csv_path: str, text_column: str = "full_text"):
    """
    Reads a CSV file containing text data, applies VADER sentiment analysis,
    and saves the results with new sentiment score columns to another CSV file.

    Args:
        input_csv_path: Path to the input CSV file with engineered features.
        output_csv_path: Path to the output CSV file with added sentiment scores.
        text_column: The name of the column containing the text to analyze.
    """
    if not nltk_vader_available:
        print("Skipping sentiment analysis as NLTK VADER is not available.")
        # Optionally, copy input to output or handle error
        if os.path.exists(input_csv_path):
            try:
                df = pd.read_csv(input_csv_path)
                df.to_csv(output_csv_path, index=False)
                print(f"Copied input to {output_csv_path} as sentiment analysis was skipped.")
            except Exception as e:
                print(f"Error processing CSV {input_csv_path} even without sentiment: {e}")
                pd.DataFrame([{"error": f"Error processing CSV: {e}"}]).to_csv(output_csv_path, index=False)
        else:
            print(f"Input file {input_csv_path} not found.")
            pd.DataFrame([{"error": f"Input file not found: {input_csv_path}"}]).to_csv(output_csv_path, index=False)
        return

    if not os.path.exists(input_csv_path):
        print(f"Error: Input CSV file not found at {input_csv_path}")
        pd.DataFrame([{"error": f"Input CSV file not found at {input_csv_path}"}]).to_csv(output_csv_path, index=False)
        return

    try:
        df = pd.read_csv(input_csv_path)
    except Exception as e:
        print(f"Error reading CSV file {input_csv_path}: {e}")
        pd.DataFrame([{"error": f"Error reading CSV: {e}"}]).to_csv(output_csv_path, index=False)
        return

    if text_column not in df.columns:
        print(f"Error: Text column 	'{text_column}	' not found in {input_csv_path}.")
        # Save the original df if text column is missing, or an error
        df.to_csv(output_csv_path, index=False) 
        print(f"Saved original data to {output_csv_path} as text column was missing.")
        return

    print(f"Applying VADER sentiment analysis to column: {text_column}")
    
    # Ensure the text column is string type and handle potential NaN values
    df[text_column] = df[text_column].astype(str).fillna("")

    sentiments = df[text_column].apply(lambda text: analyzer.polarity_scores(text) if text else {"compound": 0.0, "pos": 0.0, "neg": 0.0, "neu": 1.0})
    
    df["sentiment_compound"] = sentiments.apply(lambda x: x["compound"])
    df["sentiment_pos"] = sentiments.apply(lambda x: x["pos"])
    df["sentiment_neg"] = sentiments.apply(lambda x: x["neg"])
    df["sentiment_neu"] = sentiments.apply(lambda x: x["neu"])

    try:
        df.to_csv(output_csv_path, index=False)
        print(f"Successfully applied sentiment analysis and saved to {output_csv_path}")
    except Exception as e:
        print(f"Error saving CSV file {output_csv_path}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Apply VADER sentiment analysis to text in a CSV file.")
    parser.add_argument("-i", "--input_csv", type=str, required=True, help="Path to the input CSV file (e.g., twitter_features.csv).")
    parser.add_argument("-o", "--output_csv", type=str, required=True, help="Path to the output CSV file with sentiment scores.")
    parser.add_argument("-t", "--text_column", type=str, default="full_text", help="Name of the column containing the text to analyze.")

    args = parser.parse_args()
    apply_sentiment_analysis(args.input_csv, args.output_csv, args.text_column)

