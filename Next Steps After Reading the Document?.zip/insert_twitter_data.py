#!/usr/bin/env python3.11
import psycopg2
import json
import argparse
import os

DB_NAME = "meme_coin_db"
DB_USER = "manus_user"
DB_PASSWORD = "manus_password"
DB_HOST = "localhost" # Assuming PostgreSQL is running locally
DB_PORT = "5432"

def insert_twitter_data(json_file_path: str, query: str, search_type: str = "Top"):
    """
    Reads Twitter data from a JSON file and inserts it into the PostgreSQL database.

    Args:
        json_file_path: Path to the JSON file containing Twitter data.
        query: The original search query used to fetch this data.
        search_type: The type of search performed (e.g., Top, Latest).
    """
    if not os.path.exists(json_file_path):
        print(f"Error: JSON file not found at {json_file_path}")
        return

    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data_to_insert = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from {json_file_path}: {e}")
        return
    except Exception as e:
        print(f"Error reading file {json_file_path}: {e}")
        return

    conn = None
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )
        cur = conn.cursor()

        # The twitter_data column expects JSONB
        # The data_to_insert is the direct response from the API call
        insert_query = """
        INSERT INTO twitter_data (query, search_type, tweet_data)
        VALUES (%s, %s, %s)
        RETURNING id;
        """
        cur.execute(insert_query, (query, search_type, json.dumps(data_to_insert)))
        inserted_id = cur.fetchone()[0]
        conn.commit()
        print(f"Successfully inserted Twitter data for query 	'{query}\' from {json_file_path}. New record ID: {inserted_id}")

    except psycopg2.Error as e:
        print(f"Database error while inserting Twitter data: {e}")
        if conn:
            conn.rollback() # Roll back the transaction on error
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        if conn:
            conn.rollback()
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Insert Twitter data from JSON file into PostgreSQL.")
    parser.add_argument("-f", "--file", type=str, required=True, help="Path to the input JSON file containing Twitter data.")
    parser.add_argument("-q", "--query", type=str, required=True, help="The original search query used.")
    parser.add_argument("-t", "--type", type=str, default="Top", help="The type of search performed (e.g., Top, Latest). Default: Top")

    args = parser.parse_args()
    insert_twitter_data(args.file, args.query, args.type)

