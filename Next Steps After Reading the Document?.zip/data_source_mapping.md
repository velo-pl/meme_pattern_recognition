# Data Source Mapping

Date: May 14, 2025

This document outlines the core data categories, specific data points, and potential data sources for the Meme Coin Pattern Recognition Platform. This is based on Section III of the user-provided framework document ("Strategic Data Harvesting for Meme Coin Pattern Recognition") and its associated tables.

## 1. Price & Performance Data (Ref: Table 1)

*   **Specific Metrics:**
    *   Pre-sale price (if available)
    *   Launch price
    *   All-Time High (ATH) price and date
    *   Price at intervals (e.g., 1h, 24h, 7d, 30d post-launch/listing)
    *   Trading volume (24h, 7d, 30d)
    *   Market capitalization (circulating and fully diluted)
    *   Candlestick patterns (OHLCV data at various resolutions - e.g., 1m, 5m, 1h, 4h, 1d)
    *   Liquidity pool size and depth (for DEX-traded coins)
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **DEX Aggregators & Analytics:** DexScreener, DEXTools, GeckoTerminal, Birdeye, Pump.fun (for Solana)
        *   *Notes: Excellent for real-time price/volume charts, liquidity pool data, new pair discovery. API access needs to be investigated for each.* 
    *   **Centralized Exchange (CEX) APIs/Websites:** Binance, KuCoin, Gate.io, MEXC
        *   *Notes: For coins listed on CEXs. APIs provide historical OHLCV, order book data, trading volume. API key usually required.*
    *   **Tokenomics & Project Information Platforms:** CoinMarketCap, CoinGecko, Arkham Intelligence
        *   *Notes: Good for historical price, market cap, volume, and basic token info. APIs available, often with free tiers and rate limits.*
*   **Potential Insights/Patterns to Look For:** Volatility, pump-and-dump signatures, correlation with social hype, initial momentum, profitability for early vs. late entrants, performance in different market phases.

## 2. Tokenomics (Ref: Table 1)

*   **Specific Metrics:**
    *   Total supply, circulating supply, maximum supply
    *   Token distribution (team, investors, community, liquidity, treasury, burn allocations)
    *   Vesting schedules for team/investor tokens
    *   Burn mechanisms and history
    *   Transaction taxes/fees (buy/sell tax, reflections, liquidity fees)
    *   Smart contract details (renounced ownership, locked liquidity, presence of honeypot functions, proxy contracts, minting functions, pausable functions)
    *   Liquidity lock status & duration
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **Blockchain Explorers:** Etherscan (Ethereum), Solscan (Solana), BscScan (BNB Chain)
        *   *Notes: Direct source for contract code, total supply, holder distribution. Some explorers have APIs.*
    *   **Project Whitepapers & Websites:** Official project documentation.
        *   *Notes: Often the primary source for intended tokenomics, distribution, utility. Requires careful manual review or NLP extraction.*
    *   **Tokenomic Analysis Platforms:** Arkham Intelligence, specialized smart contract audit tools/reports (e.g., CertiK, Hacken - though reports might be paid or summarized).
    *   **DEX Tools (e.g., DEXTools, DexScreener):** Often show tax info and liquidity lock status.
    *   **Specialized Meme Coin & On-Chain Intelligence Tools:** MemeCoinTracker, Bubblemaps, Nansen, Santiment, Glassnode, BullX, Holderscan.
        *   *Notes: Can provide deeper insights into token movements, holder behavior, and smart contract red flags. API/paid access likely for advanced features.*
*   **Potential Insights/Patterns to Look For:** Inflation/deflation potential, scarcity, developer control, insider selling risk, project trustworthiness (renounced contract, locked LP), sustainability of token model, red flags like excessive team allocation or unlocked liquidity.

## 3. Holder Distribution & Concentration (Ref: Table 1)

*   **Specific Metrics:**
    *   Number of unique holders
    *   Percentage of supply held by top N wallets (e.g., top 10, 20, 100)
    *   Whale transaction monitoring (large buys/sells, accumulation/distribution patterns)
    *   Concentration of tokens among team/insiders vs. public.
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **Blockchain Explorers:** Etherscan, Solscan, BscScan (token holder lists).
    *   **On-Chain Intelligence Tools:** Nansen, Santiment, Glassnode, Bubblemaps (visualizes holder connections), Arkham Intelligence.
        *   *Notes: Crucial for identifying whale wallets, exchange wallets, and potential wallet splitting. Advanced features often require paid access.*
*   **Potential Insights/Patterns to Look For:** Risk of price manipulation by large holders, organic vs. concentrated ownership, whale sentiment/activity, early signs of dumping by large holders.

## 4. Social & Community Engagement (Ref: Table 1)

*   **Specific Metrics:**
    *   Social media mentions (X/Twitter, Reddit, Telegram, Discord, etc.) - volume and velocity
    *   Follower counts and growth rates on key platforms
    *   Engagement rates (likes, shares, comments, retweets)
    *   Sentiment analysis (positive, negative, neutral, specific emotions like FOMO, FUD)
    *   Discussion trends and emerging narratives
    *   Influencer activity and endorsements (and their authenticity)
    *   Community size and activity in dedicated groups (Telegram/Discord members, online status)
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **Social Media Analytics & Listening Tools:** LunarCrush, Brand24, Keyhole, Talkwalker, Buffer, Rival IQ.
        *   *Notes: Many offer APIs, sentiment analysis, trend identification. Pricing varies.*
    *   **Platform APIs:** X/Twitter API, Reddit API (PRAW for Python), Telegram API (Telethon for Python).
        *   *Notes: Direct access but requires careful handling of rate limits, ToS, and data parsing.*
    *   **Custom Scraping Scripts:** For platforms without robust APIs (use ethically and sparingly).
    *   **AI-Powered Analytical Platforms (integrating NLP/ML):** ClickUp AI Agents (as mentioned in doc, though this seems like a generic reference to AI capabilities rather than a specific tool for this context - likely refers to building custom solutions).
*   **Potential Insights/Patterns to Look For:** Strength of community, virality potential, organic vs. artificial hype (bot activity), impact of influencer endorsements, shifts in sentiment preceding price moves, early narrative formation.

## 5. Project Fundamentals & Development Activity (Ref: Table 1)

*   **Specific Metrics:**
    *   Whitepaper quality, clarity, and originality (presence of plagiarism, vague claims)
    *   Team transparency (anonymous vs. doxxed team, verifiable experience, LinkedIn profiles)
    *   Project roadmap and progress against stated milestones
    *   Stated utility/use case and its feasibility
    *   Security audits (from reputable firms, e.g., CertiK) and their findings
    *   GitHub activity (commit frequency, number of contributors, issue tracking) - if applicable/public
    *   Partnerships and collaborations announced
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **Project Websites & Whitepapers:** Direct source.
    *   **GitHub/GitLab:** For open-source projects.
    *   **Social Media (Team Announcements, AMAs):** X/Twitter, Telegram, Discord.
    *   **Security Audit Reports:** Often published by projects or audit firms.
    *   **News articles, forum discussions:** For broader context.
*   **Potential Insights/Patterns to Look For:** Project legitimacy, team commitment, long-term vision, potential for utility beyond speculation, security risks, signs of active vs. inactive development.

## 6. On-Chain Data & Market Metrics (Beyond Price/Volume) (Ref: Table 1)

*   **Specific Metrics:**
    *   Transaction volume (number of transactions, not just value)
    *   Liquidity pool size & depth changes over time
    *   Locked liquidity status, duration, and provider
    *   Number of unique active addresses interacting with the contract
    *   Exchange listings (DEX & CEX) and their timing
    *   Specific smart contract interactions (e.g., calls to certain functions)
    *   Gas fees and network congestion (for the underlying blockchain)
*   **Potential Data Source Examples (Ref: Table 1 & Table 2):**
    *   **Blockchain Explorers:** Etherscan, Solscan, BscScan.
    *   **DEX Analytics Platforms:** DexScreener, DEXTools, GeckoTerminal.
    *   **CEX Data:** APIs from exchanges.
    *   **Specialized On-Chain Data Platforms:** Glassnode, Nansen, Santiment, Dune.com (for custom queries on blockchain data), IntoTheBlock.
        *   *Notes: Dune is powerful for custom SQL queries on decoded blockchain data. Others provide pre-calculated metrics and advanced analytics, often via paid APIs.*
    *   **Specialized Meme Coin Tools:** MemeCoinTracker, Holderscan.
*   **Potential Insights/Patterns to Look For:** Market health, liquidity adequacy, investor confidence, impact of exchange listings on price/volume, actual token usage vs. speculation, smart contract activity patterns.

## 7. Critical Red Flags & Warning Signs (Ref: Table 3 in original document)

This is not a separate data category but a synthesis of findings from the above, specifically looking for patterns indicative of high risk:
*   **Tokenomics & Smart Contract Red Flags:** Excessive token allocation to team/insiders with no or short vesting, unlocked liquidity, ability for devs to mint new tokens arbitrarily, high transaction taxes benefiting devs, contract not renounced.
*   **Team & Development Red Flags:** Anonymous or untraceable team, lack of prior experience, no verifiable track record, no whitepaper or poorly written/plagiarized one, vague/unrealistic roadmap, no evidence of ongoing development, absence of security audits.
*   **Social Media & Community Red Flags:** Sudden explosion of artificial hype (bot activity), overly aggressive marketing with unrealistic profit promises, suppression of critical questions, primary communication channels suddenly deleted/restricted.
*   **Market Activity & Liquidity Red Flags:** Extremely low liquidity, very low number of unique holders, inability to sell tokens (honeypot), sudden massive price spikes on low volume followed by inability to trade, very low DEXT Score.
*   **Website & Whitepaper Red Flags:** No official website or poorly designed/template-based site, whitepaper missing or filled with jargon/unsubstantiated claims.

**Sources for Red Flags:** Synthesized from all the above data sources.

This mapping will serve as the foundation for developing our data collection pipelines in the next steps of Phase 2. API availability, costs, and rate limits for each potential source will need to be investigated further.
