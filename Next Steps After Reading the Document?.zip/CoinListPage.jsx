import React, { useEffect } from 'react';
import useCoinStore from '../store/coinStore'; // Adjusted path

const CoinListPage = () => {
  const { scores, isLoading, error, fetchScores } = useCoinStore();

  useEffect(() => {
    fetchScores();
  }, [fetchScores]);

  if (isLoading) return <p>Loading coins...</p>;
  if (error) return <p>Error fetching coins: {error}</p>;
  if (!scores || scores.length === 0) return <p>No coins found.</p>;

  return (
    <div>
      <h2>Coin List & Exploration</h2>
      <p>Browse, sort, and filter all analyzed meme coins. (Data from API)</p>
      {/* Placeholder for filters */}
      <div style={{ marginTop: '20px' }}>
        <input type="text" placeholder="Filter by name, symbol..." style={{ marginBottom: '10px', padding: '8px', width: '300px' }} />
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>User/Screen Name</th>
            <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Overall Potential Score</th>
            <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Sentiment Score (0-10)</th>
            <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Engagement Score (0-10)</th>
            <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Financial Stability (0-10)</th>
            {/* <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Actions</th> */}
          </tr>
        </thead>
        <tbody>
          {scores.map((coin, index) => (
            <tr key={coin.tweet_id || `coin-${index}`}> {/* Use tweet_id or index as key */}
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>{coin.user_screen_name || 'N/A'}</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>{coin.overall_potential_score_0_10 !== undefined ? coin.overall_potential_score_0_10.toFixed(2) : 'N/A'}</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>{coin.calculated_sentiment_score_0_10 !== undefined ? coin.calculated_sentiment_score_0_10.toFixed(2) : 'N/A'}</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>{coin.calculated_engagement_score_0_10 !== undefined ? coin.calculated_engagement_score_0_10.toFixed(2) : 'N/A'}</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>{coin.context_financial_stability_score_0_10 !== undefined ? coin.context_financial_stability_score_0_10.toFixed(2) : 'N/A'}</td>
              {/* <td style={{ border: '1px solid #ccc', padding: '8px' }}><a href={`/coins/${coin.tweet_id || index}`}>View Details</a></td> */}
            </tr>
          ))}
        </tbody>
      </table>
      {/* Placeholder for pagination */}
    </div>
  );
};

export default CoinListPage;
