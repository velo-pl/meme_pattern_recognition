import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from 'react-router-dom';

import Layout from './components/Layout';
import DashboardPage from './pages/DashboardPage';
import CoinListPage from './pages/CoinListPage';
import CoinDetailPage from './pages/CoinDetailPage';

// Basic styling for the app
import './App.css'; // Assuming you have some global styles

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate replace to="/dashboard" />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/coins" element={<CoinListPage />} />
          <Route path="/coins/:coinId" element={<CoinDetailPage />} />
          {/* Add other routes as needed */}
          <Route path="*" element={<div><h2>404 Not Found</h2><p>The page you are looking for does not exist.</p></div>} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
