import sys
import os

# Add the project root to the Python path to allow for absolute imports
# This assumes 'src' is directly under 'backend_api'
# Adjust if your structure is different or if main.py is moved
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify, request
import pandas as pd

app = Flask(__name__)

# Define the path to the data file relative to the backend_api directory
# This assumes your integrated_scores.csv will be placed in backend_api/data/
DATA_FILE_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "integrated_scores.csv")

@app.route("/api/v1/scores", methods=["GET"])
def get_scores():
    """Endpoint to retrieve integrated scores."""
    try:
        # Ensure the data file exists where expected
        # For now, we copy it from the main project engineered_features directory
        # In a real setup, this data might be dynamically generated or live in a DB
        source_data_path = "/home/ubuntu/meme_coin_pattern_recognition_platform/engineered_features/integrated_scores.csv"
        
        if not os.path.exists(DATA_FILE_PATH):
            if os.path.exists(source_data_path):
                # Copy the file if it doesn't exist in the target data directory
                # This is a temporary measure for development
                os.makedirs(os.path.dirname(DATA_FILE_PATH), exist_ok=True)
                import shutil
                shutil.copy(source_data_path, DATA_FILE_PATH)
                print(f"Copied data file from {source_data_path} to {DATA_FILE_PATH}")
            else:
                print(f"Source data file {source_data_path} not found.")
                return jsonify({"error": "Data file not found"}), 404

        df = pd.read_csv(DATA_FILE_PATH)
        # Convert dataframe to a list of dictionaries for JSON response
        scores = df.to_dict(orient="records")
        return jsonify({"scores": scores}), 200
    except FileNotFoundError:
        print(f"Processed data file not found at {DATA_FILE_PATH} after attempting copy.")
        return jsonify({"error": "Data file not found after copy attempt"}), 404
    except pd.errors.EmptyDataError:
        print(f"Data file {DATA_FILE_PATH} is empty.")
        return jsonify({"error": "Data file is empty"}), 500
    except Exception as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/")
def health_check():
    return jsonify({"status": "API is running"}), 200

if __name__ == "__main__":
    # Make sure to run on 0.0.0.0 to be accessible externally if exposed
    app.run(host="0.0.0.0", port=5000, debug=True)

