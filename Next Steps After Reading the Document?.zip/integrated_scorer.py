#!/usr/bin/env python3.11
import pandas as pd
import argparse
import os
import numpy as np

def calculate_scores(twitter_features_path: str, financial_features_path: str, output_path: str):
    """
    Applies a basic weighted scoring system based on engineered features from Twitter and financial data.

    Args:
        twitter_features_path: Path to CSV with Twitter features (including sentiment).
        financial_features_path: Path to CSV with financial features (including anomalies).
        output_path: Path to save the output CSV with integrated scores.
    """
    # --- Load Data ---
    try:
        twitter_df = pd.read_csv(twitter_features_path)
        print(f"Successfully loaded Twitter features from {twitter_features_path}")
    except FileNotFoundError:
        print(f"Error: Twitter features file not found at {twitter_features_path}")
        # Create an empty DataFrame with an error column if file not found
        error_df = pd.DataFrame([{"error_message": f"Twitter file not found: {twitter_features_path}"}])
        error_df.to_csv(output_path, index=False)
        return
    except Exception as e:
        print(f"Error loading Twitter features from {twitter_features_path}: {e}")
        error_df = pd.DataFrame([{"error_message": f"Error loading Twitter file: {e}"}])
        error_df.to_csv(output_path, index=False)
        return

    try:
        # For now, we assume financial data is per-coin, but AAPL is a placeholder.
        # In a real scenario, this would be iterated per coin or joined.
        # For this initial script, we will just use the AAPL data as a generic financial context.
        financial_df = pd.read_csv(financial_features_path)
        print(f"Successfully loaded financial features from {financial_features_path}")
    except FileNotFoundError:
        print(f"Error: Financial features file not found at {financial_features_path}. Proceeding with Twitter data only.")
        financial_df = pd.DataFrame() # Empty dataframe if not found, scoring will adapt
    except Exception as e:
        print(f"Error loading financial features from {financial_features_path}: {e}. Proceeding with Twitter data only.")
        financial_df = pd.DataFrame()

    # --- Define Scoring Logic (Simplified based on design document) ---
    # Weights (example, to be refined)
    W_SENTIMENT = 0.4
    W_ENGAGEMENT = 0.3
    W_FINANCIAL_STABILITY = 0.3 # (Absence of anomalies)

    results = []

    # For this initial script, we will process Twitter data row by row.
    # Financial data is treated as a general context or would need a proper join strategy for per-coin analysis.
    # Let's assume for now we are scoring each tweet context, and financial context is global (from AAPL file)

    # Calculate a general financial stability score from the financial_df (if available)
    # This is a very simplified example: score is higher if fewer anomalies.
    financial_stability_score = 5.0 # Default score if no financial data
    if not financial_df.empty and "is_anomaly" in financial_df.columns:
        total_points = len(financial_df)
        num_anomalies = financial_df["is_anomaly"].sum()
        anomaly_ratio = num_anomalies / total_points if total_points > 0 else 0
        financial_stability_score = max(0, 10 * (1 - anomaly_ratio)) # Scale 0-10
    elif not financial_df.empty:
        print("Warning: 	'is_anomaly	' column not found in financial data. Using default financial stability score.")
    else:
        print("No financial data loaded. Using default financial stability score.")


    for index, row in twitter_df.iterrows():
        # 1. Sentiment Score (0-10)
        sentiment_score = 0
        if "sentiment_compound" in row and pd.notna(row["sentiment_compound"]):
            # Normalize compound score (-1 to 1) to 0-10 scale
            sentiment_score = (row["sentiment_compound"] + 1) * 5 
        else:
            sentiment_score = 5.0 # Neutral if no sentiment
        sentiment_score = max(0, min(10, sentiment_score)) # Clamp to 0-10

        # 2. Engagement Score (0-10) - very basic example
        engagement_score = 0
        if "retweet_count" in row and "favorite_count" in row and "user_followers_count" in row and pd.notna(row["user_followers_count"]):
            followers = row["user_followers_count"]
            if followers > 0:
                # Engagement relative to followers (capped)
                engagement_rate = (row.get("retweet_count",0) + row.get("favorite_count",0)) / followers
                engagement_score = min(10, engagement_rate * 1000) # Arbitrary scaling
            else:
                engagement_score = 1.0 # Low score if no followers
        else:
            engagement_score = 3.0 # Default if data missing
        engagement_score = max(0, min(10, engagement_score))

        # Overall Score for this item (e.g., a tweet or a user profile from Twitter data)
        # Here, we combine Twitter-specific scores with the general financial context score
        overall_potential_score = (
            sentiment_score * W_SENTIMENT +
            engagement_score * W_ENGAGEMENT +
            financial_stability_score * W_FINANCIAL_STABILITY
        )
        
        # Store relevant input features along with scores
        output_row = {
            "query_term": row.get("query_term", "N/A"),
            "tweet_id": row.get("tweet_id", "N/A"),
            "full_text": row.get("full_text", "N/A"),
            "user_screen_name": row.get("user_screen_name", "N/A"),
            "sentiment_compound_input": row.get("sentiment_compound", np.nan),
            "calculated_sentiment_score_0_10": sentiment_score,
            "calculated_engagement_score_0_10": engagement_score,
            "context_financial_stability_score_0_10": financial_stability_score,
            "overall_potential_score_0_10": overall_potential_score
        }
        results.append(output_row)

    if not results:
        print("No data processed to generate scores.")
        # Create an empty DataFrame with an error column if no results
        error_df = pd.DataFrame([{"error_message": "No data processed to generate scores"}])
        error_df.to_csv(output_path, index=False)
        return
        
    output_df = pd.DataFrame(results)
    
    try:
        output_df.to_csv(output_path, index=False)
        print(f"Successfully calculated integrated scores and saved to {output_path}")
    except Exception as e:
        print(f"Error saving output CSV to {output_path}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Integrated Scoring Framework - Initial Version")
    parser.add_argument("--twitter_csv", required=True, help="Path to Twitter features CSV (with sentiment)")
    parser.add_argument("--financial_csv", required=True, help="Path to Financial features CSV (with anomalies)")
    parser.add_argument("--output_csv", required=True, help="Path for the output CSV with integrated scores")
    
    args = parser.parse_args()
    
    calculate_scores(args.twitter_csv, args.financial_csv, args.output_csv)

