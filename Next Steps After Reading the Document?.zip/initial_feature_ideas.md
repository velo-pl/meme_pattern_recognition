# Initial Feature Ideas for Meme Coin Pattern Recognition

Date: May 14, 2025

This document outlines initial ideas for features that can be engineered from the data sources we have started to collect (Twitter and Yahoo Finance). This is a living document and will be expanded as we integrate more data sources and refine our understanding.

## I. Features from Twitter Data (via `Twitter/search_twitter` API)

Raw data typically includes tweet text, user information, engagement counts (likes, retweets, replies), timestamps, etc.

**Potential Features:**

1.  **Sentiment Scores:**
    *   **Per Tweet Sentiment:** Positive, Negative, Neutral score for each relevant tweet (requires NLP model, e.g., VADER, Transformers-based).
    *   **Aggregated Sentiment:** Average/median sentiment score over a time window (e.g., hourly, daily) for a specific coin/query.
    *   **Sentiment Volatility:** Standard deviation of sentiment scores over a time window.
    *   **Ratio of Positive to Negative Mentions:** A simple metric for overall sentiment direction.

2.  **Engagement Metrics (per coin/query over time windows):**
    *   **Tweet Volume:** Number of tweets mentioning the coin.
    *   **Retweet Volume:** Total number of retweets.
    *   **Like Volume:** Total number of likes.
    *   **Reply Volume:** Total number of replies.
    *   **Engagement Rate:** (Likes + Retweets + Replies) / Number of Followers (if user data is consistently available and relevant) or per tweet.
    *   **Velocity of Mentions/Engagement:** Rate of change of tweet volume or engagement metrics (e.g., 1-hour change, 24-hour change).
    *   **Unique User Count:** Number of unique users tweeting about the coin (helps identify astroturfing vs. organic interest).

3.  **User-based Features (if user data is detailed enough):**
    *   **Influencer Mentions:** Binary flag or count of mentions by pre-identified influential accounts.
    *   **Verified User Mentions:** Count/ratio of mentions by verified Twitter users.
    *   **Account Age of Tweeters:** Average/median account age of users mentioning the coin (very new accounts might indicate bot activity).
    *   **Follower Count of Tweeters:** Average/median follower count of users mentioning the coin.

4.  **Text-based Features (requires NLP):**
    *   **Keyword/Hashtag Frequency:** Frequency of specific keywords (e.g., "to the moon", "scam", "presale", "rugpull", project-specific terms).
    *   **Topic Modeling:** Identifying dominant topics of discussion around a coin.
    *   **Named Entity Recognition:** Extracting project names, people, organizations mentioned alongside the coin.
    *   **FOMO/FUD Indicators:** Presence of language strongly indicating Fear Of Missing Out or Fear, Uncertainty, and Doubt.

## II. Features from Yahoo Finance Data (via `YahooFinance/get_stock_chart` etc.)

This data is primarily for coins that get listed and have chart data available (e.g., DOGE-USD). For new presale meme coins, this might be less relevant initially but crucial for post-launch analysis if they get listed on platforms Yahoo Finance tracks.

**A. From `get_stock_chart` (Price/Volume Data):**

*   **Basic Price & Volume Features:**
    *   Open, High, Low, Close prices (OHLC).
    *   Trading Volume.
    *   Market Capitalization (if available directly or can be derived).
*   **Technical Indicators (Calculated from OHLCV):**
    *   **Moving Averages:** Simple Moving Average (SMA), Exponential Moving Average (EMA) for various periods (e.g., 7, 14, 30, 50, 200 periods).
    *   **Moving Average Crossovers:** Signals from short-term MA crossing long-term MA.
    *   **Relative Strength Index (RSI):** Momentum oscillator.
    *   **Moving Average Convergence Divergence (MACD):** Trend-following momentum indicator.
    *   **Bollinger Bands:** Volatility bands.
    *   **Stochastic Oscillator:** Momentum indicator comparing closing price to a range of its prices over a certain period.
    *   **Average True Range (ATR):** Market volatility.
*   **Price/Volume Derived Features:**
    *   **Price Change Percentage:** (e.g., 1h, 24h, 7d).
    *   **Volume Change Percentage:** (e.g., 1h, 24h, 7d).
    *   **Price Volatility:** Standard deviation of price over a window.
    *   **On-Balance Volume (OBV):** Cumulative volume indicator.
    *   **Correlation:** Price correlation with benchmark assets (e.g., BTC, ETH, or a meme coin index if created).

**B. From `get_stock_holders` (Insider/Major Holder Data - less likely for meme coins unless they are tied to publicly traded entities):**

*   **Insider Transaction Volume/Sentiment:** (If applicable, very rare for typical meme coins).
*   **Change in Institutional Holdings:** (If applicable).

**C. From `get_stock_insights` (Analyst Opinions, Technical Events - again, more for established assets):**

*   **Technical Event Signals:** Short/Intermediate/Long-term outlook scores/directions (if available for the asset).
    *   Innovativeness, Sustainability, Hiring scores (if available).
*   **Valuation Metrics:** (If available).

**D. From `get_stock_sec_filing` (SEC Filings - primarily for US-based publicly traded companies, not directly for most meme coins):**

*   **Frequency/Type of Filings:** (Unlikely to be relevant for most meme coins unless a related entity is public).

## III. Cross-Source Features (Combining Twitter & Financial Data)

*   **Sentiment-Price Correlation:** Correlation between aggregated sentiment and price movements.
*   **Tweet Volume-Trading Volume Correlation:** Correlation between social buzz and trading activity.
*   **Lagged Features:** E.g., does a spike in Twitter mentions precede a price pump by X hours/days?

## Next Steps for Feature Engineering:

1.  **Data Exploration:** Dive deeper into the actual JSON structures of the collected data to confirm available fields.
2.  **Prioritization:** Decide which features are most promising for initial model development based on project goals (scam detection, identifying promising presales).
3.  **Implementation:** Develop Python scripts to calculate these features from the raw data stored in the PostgreSQL database.
4.  **Storage:** Decide how and where to store these engineered features (e.g., new tables in PostgreSQL, or as part of a data processing pipeline that feeds models directly).

This list will be refined and expanded as we proceed with Phase 3.

