import { create } from 'zustand';
import { getScores } from '../services/apiService';

const useCoinStore = create((set) => ({
  scores: [],
  isLoading: false,
  error: null,
  fetchScores: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await getScores();
      // The API returns { "scores": [...] }, so we access response.data.scores
      set({ scores: response.data.scores || [], isLoading: false });
    } catch (error) {
      console.error('Error fetching scores:', error);
      set({ error: error.message || 'Failed to fetch scores', isLoading: false, scores: [] });
    }
  },
}));

export default useCoinStore;

