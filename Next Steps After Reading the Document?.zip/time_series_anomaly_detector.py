#!/usr/bin/env python3.11
import pandas as pd
import numpy as np
import argparse
import os

def detect_anomalies_statistical(input_csv_path: str, output_csv_path: str, column_to_analyze: str = "price_change_pct_1d", window: int = 20, std_dev_threshold: float = 3.0):
    """
    Reads a CSV file with time-series data, applies statistical anomaly detection 
    (e.g., Z-score on a rolling basis or based on overall distribution) to a specified column,
    and saves the results with an added anomaly flag column.

    Args:
        input_csv_path: Path to the input CSV file (e.g., AAPL_features.csv).
        output_csv_path: Path to the output CSV file with an is_anomaly column.
        column_to_analyze: The name of the column to perform anomaly detection on.
        window: The rolling window size for calculating mean and std dev (if using rolling Z-score).
                 If window is 0 or None, uses global mean and std dev.
        std_dev_threshold: Number of standard deviations from the mean to consider an anomaly.
    """
    if not os.path.exists(input_csv_path):
        print(f"Error: Input CSV file not found at {input_csv_path}")
        pd.DataFrame([{"error": f"Input CSV file not found at {input_csv_path}"}]).to_csv(output_csv_path, index=False)
        return

    try:
        df = pd.read_csv(input_csv_path)
    except Exception as e:
        print(f"Error reading CSV file {input_csv_path}: {e}")
        pd.DataFrame([{"error": f"Error reading CSV: {e}"}]).to_csv(output_csv_path, index=False)
        return

    if column_to_analyze not in df.columns:
        # Corrected print statement below
        print(f"Error: Column 	'{column_to_analyze}'	 not found in {input_csv_path}.")
        df.to_csv(output_csv_path, index=False) # Save original if column missing
        print(f"Saved original data to {output_csv_path} as column_to_analyze was missing.")
        return

    print(f"Applying anomaly detection to column: {column_to_analyze} with threshold: {std_dev_threshold} std devs.")

    # Ensure the column is numeric and handle NaNs by filling with 0 or mean, or dropping
    # For this example, we will fill NaNs with 0, which might not always be appropriate.
    # A better approach might be to drop rows with NaNs in this column or use imputation.
    df[column_to_analyze] = pd.to_numeric(df[column_to_analyze], errors="coerce").fillna(0)

    if window and window > 0:
        # Rolling Z-score approach
        df["rolling_mean"] = df[column_to_analyze].rolling(window=window, center=True, min_periods=1).mean()
        df["rolling_std"] = df[column_to_analyze].rolling(window=window, center=True, min_periods=1).std()
        # Replace NaN in rolling_std with a large number to avoid division by zero or with global std if preferred
        df["rolling_std"].fillna(df[column_to_analyze].std(), inplace=True) # Fill NaN std with global std
        df["rolling_std"].replace(0, np.nan, inplace=True) # Avoid division by zero if std is truly 0
        df["rolling_std"].fillna(1, inplace=True) # If std is still 0 (e.g. constant series), set to 1 to avoid issues

        df["z_score"] = (df[column_to_analyze] - df["rolling_mean"]) / df["rolling_std"]
    else:
        # Global Z-score approach
        mean_val = df[column_to_analyze].mean()
        std_val = df[column_to_analyze].std()
        if std_val == 0: # Handle case of constant series
            std_val = 1 # Avoid division by zero
        df["z_score"] = (df[column_to_analyze] - mean_val) / std_val

    df["is_anomaly"] = np.abs(df["z_score"]) > std_dev_threshold

    # Clean up intermediate columns if not needed in output
    if window and window > 0:
        df.drop(columns=["rolling_mean", "rolling_std"], inplace=True, errors="ignore")

    try:
        df.to_csv(output_csv_path, index=False)
        print(f"Successfully applied anomaly detection and saved to {output_csv_path}")
        num_anomalies = df["is_anomaly"].sum()
        print(f"Number of anomalies detected: {num_anomalies}")
    except Exception as e:
        print(f"Error saving CSV file {output_csv_path}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Apply statistical anomaly detection to a CSV column.")
    parser.add_argument("-i", "--input_csv", type=str, required=True, help="Path to the input CSV file.")
    parser.add_argument("-o", "--output_csv", type=str, required=True, help="Path to the output CSV file.")
    parser.add_argument("-c", "--column", type=str, default="price_change_pct_1d", help="Column to analyze for anomalies.")
    parser.add_argument("-w", "--window", type=int, default=0, help="Rolling window for Z-score (0 for global Z-score).")
    parser.add_argument("-t", "--threshold", type=float, default=3.0, help="Standard deviation threshold for anomalies.")

    args = parser.parse_args()
    detect_anomalies_statistical(args.input_csv, args.output_csv, args.column, args.window, args.threshold)

