#!/usr/bin/env python3.11
import json
import pandas as pd
import argparse
import os

# Ensure pandas is available, if not, it would need to be installed via pip
# For this environment, we assume pandas is available or can be installed.

def engineer_yahoo_finance_chart_features(json_file_path: str, output_csv_file: str):
    """
    Reads Yahoo Finance chart data from a JSON file, engineers basic features,
    and saves them to a CSV file.

    Args:
        json_file_path: Path to the input JSON file containing Yahoo Finance chart data.
        output_csv_file: Path to the output CSV file for engineered features.
    """
    if not os.path.exists(json_file_path):
        print(f"Error: JSON file not found at {json_file_path}")
        return

    try:
        with open(json_file_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from {json_file_path}: {e}")
        return
    except Exception as e:
        print(f"Error reading file {json_file_path}: {e}")
        return

    try:
        # Navigate to the relevant part of the JSON structure
        # Based on YahooFinance/get_stock_chart API response schema
        if not raw_data or "chart" not in raw_data or not raw_data["chart"]["result"]:
            print(f"Error: Unexpected JSON structure or empty data in {json_file_path}. Cannot find chart.result.")
            # Save an empty CSV or a CSV with an error message
            pd.DataFrame([{"error": "Unexpected JSON structure or empty data"}]).to_csv(output_csv_file, index=False)
            return

        chart_result = raw_data["chart"]["result"][0]
        timestamps = chart_result.get("timestamp", [])
        indicators = chart_result.get("indicators", {})
        quote = indicators.get("quote", [{}])[0]
        adjclose_data = indicators.get("adjclose", [{}])[0].get("adjclose", [])

        if not timestamps or not quote.get("open"):
            print(f"Error: Timestamps or OHLCV data missing in {json_file_path}.")
            pd.DataFrame([{"error": "Timestamps or OHLCV data missing"}]).to_csv(output_csv_file, index=False)
            return

        df = pd.DataFrame({
            "timestamp": pd.to_datetime(timestamps, unit="s"),
            "open": quote.get("open", [None]*len(timestamps)),
            "high": quote.get("high", [None]*len(timestamps)),
            "low": quote.get("low", [None]*len(timestamps)),
            "close": quote.get("close", [None]*len(timestamps)),
            "volume": quote.get("volume", [None]*len(timestamps)),
            "adjclose": adjclose_data if len(adjclose_data) == len(timestamps) else [None]*len(timestamps)
        })

        df.set_index("timestamp", inplace=True)
        df.sort_index(inplace=True)
        df.dropna(subset=["close"], inplace=True) # Ensure close price is not null for calculations

        if df.empty:
            print(f"DataFrame is empty after processing {json_file_path}. No features to engineer.")
            pd.DataFrame([{"error": "No valid data to process after cleaning"}]).to_csv(output_csv_file, index=False)
            return

        # Feature Engineering Examples:
        # 1. Price Change (Percentage)
        df["price_change_pct_1d"] = df["close"].pct_change(periods=1) * 100

        # 2. Simple Moving Averages (SMA)
        df["sma_7d"] = df["close"].rolling(window=7, min_periods=1).mean()
        df["sma_30d"] = df["close"].rolling(window=30, min_periods=1).mean()
        
        # 3. Exponential Moving Average (EMA)
        df["ema_7d"] = df["close"].ewm(span=7, adjust=False, min_periods=1).mean()

        # 4. Volatility (Rolling Standard Deviation of Price Change)
        df["volatility_7d_pct_change"] = df["price_change_pct_1d"].rolling(window=7, min_periods=1).std()
        
        # 5. Volume Change (Percentage)
        df["volume_change_pct_1d"] = df["volume"].pct_change(periods=1) * 100
        df["volume_sma_7d"] = df["volume"].rolling(window=7, min_periods=1).mean()

        # Add symbol from filename if possible (basic parsing)
        base_name = os.path.basename(json_file_path)
        symbol_part = base_name.split("_")[0] # Assumes format like DOGE-USD_chart_1d_1mo.json
        df["symbol"] = symbol_part
        
        df.reset_index(inplace=True) # Make timestamp a column again for CSV

        df.to_csv(output_csv_file, index=False)
        print(f"Successfully engineered features and saved to {output_csv_file}")

    except KeyError as e:
        print(f"KeyError while processing JSON structure in {json_file_path}: {e}. Check API response format.")
        pd.DataFrame([{"error": f"KeyError: {e}"}]).to_csv(output_csv_file, index=False)
    except Exception as e:
        print(f"An unexpected error occurred during feature engineering for {json_file_path}: {e}")
        # Save an error CSV
        pd.DataFrame([{"error": str(e)}]).to_csv(output_csv_file, index=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Engineer features from Yahoo Finance chart data.")
    parser.add_argument("-f", "--file", type=str, required=True, help="Path to the input JSON file (e.g., DOGE-USD_chart_1d_1mo.json).")
    parser.add_argument("-o", "--output_csv", type=str, required=True, help="Path to the output CSV file for engineered features.")

    args = parser.parse_args()
    engineer_yahoo_finance_chart_features(args.file, args.output_csv)

