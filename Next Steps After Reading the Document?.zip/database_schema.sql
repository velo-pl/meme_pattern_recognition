-- Initial Schema for Meme Coin Pattern Recognition Platform
-- Date: May 14, 2025

-- 1. Twitter Data
-- Storing raw JSON for flexibility initially, can be normalized later.
CREATE TABLE IF NOT EXISTS twitter_data (
    id SERIAL PRIMARY KEY,
    query VARCHAR(255) NOT NULL,
    search_type VARCHAR(50),
    tweet_data JSONB NOT NULL, -- Stores the entire tweet object or list of tweets
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Grant privileges to manus_user for this table
GRANT ALL PRIVILEGES ON TABLE twitter_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE twitter_data_id_seq TO manus_user;

-- 2. Yahoo Finance Chart Data
-- Storing raw JSON for flexibility.
CREATE TABLE IF NOT EXISTS yahoo_finance_chart_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(50) NOT NULL,
    interval_period VARCHAR(10) NOT NULL, -- e.g., 1d, 1mo
    data_range VARCHAR(10) NOT NULL, -- e.g., 1mo, 1y
    region VARCHAR(10),
    chart_data JSONB NOT NULL,
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

GRANT ALL PRIVILEGES ON TABLE yahoo_finance_chart_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE yahoo_finance_chart_data_id_seq TO manus_user;

-- 3. Yahoo Finance Holders Data
-- Storing raw JSON.
CREATE TABLE IF NOT EXISTS yahoo_finance_holders_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(50) NOT NULL,
    region VARCHAR(10),
    lang VARCHAR(10),
    holders_data JSONB NOT NULL,
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

GRANT ALL PRIVILEGES ON TABLE yahoo_finance_holders_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE yahoo_finance_holders_data_id_seq TO manus_user;

-- 4. Yahoo Finance Insights Data
-- Storing raw JSON.
CREATE TABLE IF NOT EXISTS yahoo_finance_insights_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(50) NOT NULL,
    insights_data JSONB NOT NULL,
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

GRANT ALL PRIVILEGES ON TABLE yahoo_finance_insights_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE yahoo_finance_insights_data_id_seq TO manus_user;

-- 5. Yahoo Finance SEC Filings Data
-- Storing raw JSON.
CREATE TABLE IF NOT EXISTS yahoo_finance_sec_filings_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(50) NOT NULL,
    region VARCHAR(10),
    lang VARCHAR(10),
    sec_filings_data JSONB NOT NULL,
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

GRANT ALL PRIVILEGES ON TABLE yahoo_finance_sec_filings_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE yahoo_finance_sec_filings_data_id_seq TO manus_user;

-- Add more tables as other data sources are integrated (e.g., CoinMarketCap, CoinGecko, Blockchain explorers)

-- Example: A generic table for other API data if schema is not yet defined
CREATE TABLE IF NOT EXISTS generic_api_data (
    id SERIAL PRIMARY KEY,
    source_name VARCHAR(100) NOT NULL, -- e.g., CoinMarketCap_listings, DexScreener_pairs
    query_params JSONB, -- Store parameters used for the API call
    api_response JSONB NOT NULL,
    collected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

GRANT ALL PRIVILEGES ON TABLE generic_api_data TO manus_user;
GRANT USAGE, SELECT ON SEQUENCE generic_api_data_id_seq TO manus_user;


-- Log successful schema creation


